//
//  ViewController.swift
//  lab191018
//
//  Created by Patrick Kainz on 19.10.18.
//  Copyright © 2018 Patrick Kainz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

